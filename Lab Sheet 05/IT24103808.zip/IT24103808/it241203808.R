setwd("C:/Users/it24103808/Desktop/IT24103808")
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
head(Delivery_Times)


              
                 breaks <- seq(20, 70, length.out = 10)
                 hist_data <- hist(Delivery_Times$Delivery_Time,
                                   breaks = breaks,
                                   right = FALSE,
                                   plot = FALSE)
                 cum_freq <- cumsum(hist_data$counts)
                 plot(hist_data$breaks[-1], cum_freq, type = "o",
                      main = "Cumulative Frequency Polygon (Ogive)",
                      xlab = "Delivery Time (minutes)",
                      ylab = "Cumulative Frequency",
                      col = "red", pch = 16)
                 
                 